import 'package:chatify/screens/chat_screen/chats_screen.dart';
import 'package:chatify/screens/contact_screen/create_group_screen.dart';
import 'package:chatify/screens/home_screen/chat_inbox.dart';
import 'package:flutter/material.dart';

class ContactScreen extends StatefulWidget {
  const ContactScreen({super.key});

  @override
  State<ContactScreen> createState() => contactscreenState();
}

class contactscreenState extends State<ContactScreen> {
  // List<Contact>? contacts;
  // bool _permissionDenied = false;

  @override
  void initState() {
    super.initState();
    // _fetchContacts();
  }

  // Future _fetchContacts() async {
  //   await FlutterContacts.requestPermission();
  //   var per = await Permission.contacts.request();
  //   if (per.isDenied) {
  //     setState(() => _permissionDenied = true);
  //   } else {
  //     final contacts = await FlutterContacts.getContacts(
  //         withProperties: true, deduplicateProperties: true);
  //     setState(() => contacts = contacts);
  //   }
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          centerTitle: false,
          titleSpacing: 0,
          title: ListTile(
            textColor: Colors.white,
            title: const Text("Select Contact"),
            subtitle: Text(
              "${contacts?.length ?? 0} contacts",
              style: const TextStyle(color: Colors.grey),
            ),
          ),
          actions: [
            IconButton(onPressed: () {}, icon: const Icon(Icons.search)),
            // IconButton(onPressed: () {}, icon: const Icon(Icons.call)),
            PopupMenuButton(
              padding: EdgeInsets.zero,
              itemBuilder: (context) {
                return [
                  const PopupMenuItem(
                    value: "Invite a friend",
                    child: Text("Invite a friend"),
                  ),
                  const PopupMenuItem(
                    value: "Contacts",
                    child: Text("Contacts"),
                  ),
                  const PopupMenuItem(
                    value: "Refresh",
                    child: Text("Refresh"),
                  ),
                  const PopupMenuItem(
                    value: "Help",
                    child: Text("Help"),
                  ),
                ];
              },
            ),
          ],
        ),
        body: _body());
  }

  Widget _body() {
    // if (_permissionDenied) {
    //   return const Center(child: Text('Permission denied.'));
    // }
    if (contacts == null) {
      return const Center(child: CircularProgressIndicator());
    }
    return ListView(
      children: [
        const SizedBox(height: 10),
        ListTile(
          onTap: () {
            Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const CreateGroupScreen(),
                ));
          },
          leading: CircleAvatar(
            radius: 25,
            backgroundColor: Colors.green.shade400,
            child: const Icon(
              Icons.groups,
              color: Colors.white,
              size: 35,
            ),
          ),
          title: const Text(
            "New Group",
            style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
          ),
        ),
        const SizedBox(height: 10),
        ListTile(
          onTap: () {
            Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const CreateGroupScreen(),
                ));
          },
          leading: CircleAvatar(
            radius: 25,
            backgroundColor: Colors.green.shade400,
            child: const Icon(
              Icons.groups,
              color: Colors.white,
              size: 35,
            ),
          ),
          title: const Text(
            "New Broadcast",
            style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
          ),
        ),
        const Divider(),
        ListView.builder(
            itemCount: contacts!.length,
            physics: const NeverScrollableScrollPhysics(),
            cacheExtent: 100,
            shrinkWrap: true,
            itemBuilder: (context, i) => ListTile(
                  onTap: () {
                    characters.add(contacts![i]);
                    setState(() {});
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) =>
                              ChatScreen(contact: contacts![i]),
                        ));
                  },
                  leading: CircleAvatar(
                    radius: 25,
                    backgroundColor: Colors.grey.shade400,
                    child: const Icon(
                      Icons.person,
                      color: Colors.white,
                      size: 35,
                    ),
                  ),
                  title: Text(
                    contacts![i].displayName,
                    style: const TextStyle(
                        fontWeight: FontWeight.w600, fontSize: 14),
                  ),
                  subtitle: const Text(
                    "Hey there! I am using WhatsApp.",
                    style: TextStyle(color: Colors.grey, fontSize: 12),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                )),
      ],
    );
  }
}
