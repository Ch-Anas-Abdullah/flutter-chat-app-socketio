import 'package:chatify/widgets/media_query_size.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_contacts/flutter_contacts.dart';
List<Contact>? contacts;
class CreateGroupScreen extends StatefulWidget {
  const CreateGroupScreen({super.key});

  @override
  State<CreateGroupScreen> createState() => _CreateGroupScreenState();
}

class _CreateGroupScreenState extends State<CreateGroupScreen>
    with TickerProviderStateMixin {
  
  bool _permissionDenied = false;
  List selectedNum = [];
  
  @override
  void initState() {
    
    
    super.initState();
  }

  // Future _fetchContacts() async {
  //   await FlutterContacts.requestPermission();
  //   var per = await Permission.contacts.request();
  //   if (per.isDenied) {
  //     setState(() => _permissionDenied = true);
  //   } else {
  //     final contacts = await FlutterContacts.getContacts(
  //         withProperties: true, deduplicateProperties: true);
      
  //     contacts = contacts;
      
      
  //   }
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        floatingActionButton: selectedNum.isEmpty
            ? null
            : FloatingActionButton(
                onPressed: () {},
                child: const Icon(Icons.arrow_forward_rounded),
              ).animate().fadeIn(),
        appBar: AppBar(
          centerTitle: false,
          titleSpacing: 0,
          title: ListTile(
            textColor: Colors.white,
            title: const Text("New Group"),
            subtitle: Text(
              "${contacts?.length ?? 0} contacts",
              style: const TextStyle(color: Colors.grey),
            ),
          ),
          actions: [
            IconButton(onPressed: () {}, icon: const Icon(Icons.search)),
          ],
        ),
        body: _body());
  }

  Widget _body() {
    if (_permissionDenied) {
      return const Center(child: Text('Permission denied'));
    }
    if (contacts == null) {
      return const Center(child: CircularProgressIndicator());
    }
    return SizedBox(
      height: context.height,
      width: context.width,
      child: Stack(
        children: [
          if (selectedNum.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(left: 20, top: 15),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    height: 80,
                    width: context.width,
                    child: ListView.builder(
                      shrinkWrap: true,
                      itemCount: selectedNum.length,
                      padding: const EdgeInsets.only(right: 30),
                      scrollDirection: Axis.horizontal,
                      itemBuilder: (context, index) {
                        return Padding(
                          key: UniqueKey(),
                          padding: const EdgeInsets.only(
                            right: 15,
                          ),
                          child: GestureDetector(
                            onTap: () {
                              setState(() {
                                selectedNum.remove(selectedNum[index]);
                              });
                            },
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                SizedBox(
                                  height: 55,
                                  width: 55,
                                  child: Stack(
                                    children: [
                                      CircleAvatar(
                                        radius: 25,
                                        backgroundColor: Colors.grey.shade400,
                                        child: const Icon(
                                          Icons.person,
                                          color: Colors.white,
                                          size: 35,
                                        ),
                                      ),
                                      Positioned(
                                          bottom: 6,
                                          right: 4,
                                          child: Container(
                                            height: 20,
                                            width: 20,
                                            alignment: Alignment.center,
                                            // duration: const Duration(milliseconds: 1500),
                                            // curve: Curves.elasticInOut,
                                            decoration: BoxDecoration(
                                                shape: BoxShape.circle,
                                                border: Border.all(
                                                    color: Colors.white),
                                                color: Colors.grey),
                                            child: const Icon(
                                              Icons.close,
                                              color: Colors.white,
                                              size: 15,
                                            ),
                                          ))
                                    ],
                                  ),
                                ),
                                SizedBox(
                                  width: 65,
                                  child: Text(
                                    contacts?[selectedNum[index]]
                                            .displayName ??
                                        "",
                                    maxLines: 1,
                                    textAlign: TextAlign.center,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(fontSize: 13),
                                  ),
                                )
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                  const Padding(
                    padding: EdgeInsets.only(
                      right: 20,
                    ),
                    child: Divider(),
                  ),
                ],
              ),
            ).animate().fadeIn(),
          AnimatedPositioned(
            duration: const Duration(milliseconds: 400),
            top: selectedNum.isEmpty ? 0 : 110,
            child: SizedBox(
              width: context.width,
              height: selectedNum.isEmpty
                  ? context.height - kToolbarHeight
                  : context.height - kToolbarHeight - 110,
              child: ListView.builder(
                  itemCount: contacts!.length,
                  shrinkWrap: true,
                  padding: const EdgeInsets.only(top: 15, bottom: 60),
                  itemBuilder: (context, i) {
                    return ListTile(
                      onTap: () async {
                        setState(()  {
                          if (selectedNum.contains(i)) {
                            selectedNum.remove(i);
                          } else {
                            selectedNum.insert(0, i);
                            
                            
                          }
                        });
                        await Future.delayed(const Duration(seconds: 1));
                            
                      },
                      leading: SizedBox(
                        height: 55,
                        width: 55,
                        child: Stack(
                          children: [
                            CircleAvatar(
                              radius: 25,
                              backgroundColor: Colors.grey.shade400,
                              child: const Icon(
                                Icons.person,
                                color: Colors.white,
                                size: 35,
                              ),
                            ),
                            if (selectedNum.contains(i))
                              Positioned(
                                  bottom: 6,
                                  right: 4,
                                  child: Container(
                                    height: 20,
                                    width: 20,
                                    alignment: Alignment.center,
                                    // duration: const Duration(milliseconds: 1500),
                                    // curve: Curves.elasticInOut,
                                    decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        border: Border.all(color: Colors.white),
                                        color: Colors.green.shade300),
                                    child: const Icon(
                                      Icons.check,
                                      color: Colors.white,
                                      size: 15,
                                    ),
                                  )).animate().fadeIn(curve: Curves.ease)
                          ],
                        ),
                      ),
                      title: Text(
                        contacts![i].displayName,
                        style: const TextStyle(
                            fontWeight: FontWeight.w600, fontSize: 14),
                      ),
                      subtitle: const Text(
                        "Hey there! I am using WhatsApp.",
                        style: TextStyle(color: Colors.grey, fontSize: 12),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    );
                  }),
            ),
          ),
        ],
      ),
    );
  }
}
