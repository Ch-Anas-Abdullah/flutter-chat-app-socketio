import 'package:chatify/widgets/media_query_size.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:readmore/readmore.dart';

class CustomChatBubble extends StatelessWidget {
  final bool isMe;
  final String message;
  const CustomChatBubble(
      {super.key, required this.isMe, required this.message});

  @override
  Widget build(BuildContext context) {
    return isMe
        ? Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Text(
                    DateFormat('hh:mm a').format(DateTime.now()).toString(),
                    style: const TextStyle(fontSize: 11,
                    color: Colors.grey,),
                    
                  ),
                  const Icon(
                    Icons.check,
                    color: Colors.grey,
                    size: 15,
                  ),
                ],
              ),
              const SizedBox(width: 5),
              Container(
                  padding: const EdgeInsets.all(12),
                  decoration: const BoxDecoration(
                      color: Colors.orange,
                      // boxShadow: [
                      //   BoxShadow(
                      //     color: Colors.grey.shade400,
                      //     spreadRadius: 1,
                      //     blurRadius: 5,
                      //     offset: const Offset(-1, 3),
                      //   ),
                      // ],
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(20),
                          topRight: Radius.circular(20),
                          bottomRight: Radius.circular(0),
                          bottomLeft: Radius.circular(20))),
                  constraints: BoxConstraints(maxWidth: context.width * 0.70),
                  child: ReadMoreText(
                    message,
                    style:
                        GoogleFonts.poppins(fontSize: 15, color: Colors.white),
                    colorClickableText: Colors.purple,
                    trimLength: 400,
                    textAlign: TextAlign.justify,
                  )),
              const SizedBox(width: 10),
            ],
          )
        : Row(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                      color: Colors.white,
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.shade400,
                          spreadRadius: 1,
                          blurRadius: 5,
                          offset: const Offset(-1, 3),
                        ),
                      ],
                      borderRadius: const BorderRadius.only(
                          topLeft: Radius.circular(20),
                          topRight: Radius.circular(20),
                          bottomRight: Radius.circular(20),
                          bottomLeft: Radius.circular(0))),
                  constraints: BoxConstraints(maxWidth: context.width * 0.70),
                  child: ReadMoreText(
                    message,
                    style: GoogleFonts.poppins(
                      fontSize: 15,
                    ),
                    colorClickableText: Colors.orange,
                    trimLength: 400,
                    textAlign: TextAlign.justify,
                  )),
              const SizedBox(width: 10),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                   Text(
                    DateFormat('hh:mm a').format(DateTime.now()).toString(),
                    style: const TextStyle(fontSize: 11,
                    color: Colors.grey,),
                    
                  ),
                  const Icon(
                    Icons.check,
                    color: Colors.grey,
                    size: 15,
                  ),
                ],
              ),
            ],
          );
  }
}
