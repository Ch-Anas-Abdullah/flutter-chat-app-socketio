import 'package:chatify/screens/contact_screen/contact_screen.dart';
import 'package:chatify/widgets/chat_card.dart';
import 'package:flutter/material.dart';
import 'package:flutter_contacts/flutter_contacts.dart';

class ChatInboxScreen extends StatefulWidget {
  const ChatInboxScreen({super.key});

  @override
  State<ChatInboxScreen> createState() => _ChatInboxScreenState();
}

List<Contact> characters = [];

class _ChatInboxScreenState extends State<ChatInboxScreen> {
  @override
  void initState() {
    super.initState();
    characters.shuffle();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton(
          onPressed: () {
            Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const ContactScreen(),
                ));
          },
          child: const Icon(Icons.chat)),
      body: ListView.builder(
        itemCount: characters.length,
        shrinkWrap: true,
        padding: const EdgeInsets.only(top: 15, bottom: 100),
        itemBuilder: (context, index) {
          return ChatCard(
            contact: characters[index],
          );
        },
      ),
    );
  }
}
