import 'package:chatify/screens/camera_screen/camera_screen.dart';
import 'package:chatify/screens/home_screen/chat_inbox.dart';
import 'package:chatify/widgets/media_query_size.dart';
import 'package:flutter/material.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with SingleTickerProviderStateMixin {
  late TabController tabController;
  @override
  void initState() {
    tabController = TabController(length: 3, vsync: this, initialIndex: 0);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Chatify"),
        automaticallyImplyLeading: false,
        actions: [
          IconButton(onPressed: () {}, icon: const Icon(Icons.search)),
          IconButton(
              onPressed: () {
                Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const CameraScreen(),
                    ));
              },
              icon: const Icon(Icons.camera_alt_outlined)),
          PopupMenuButton(
            // position: PopupMenuPosition.under,
            itemBuilder: (context) {
              return [
                const PopupMenuItem(
                  value: "New Group",
                  child: Text("New Group"),
                ),
                const PopupMenuItem(
                  value: "New Broadcast",
                  child: Text("New Broadcast"),
                ),
                const PopupMenuItem(
                  value: "Stared Messages",
                  child: Text("Stared Messages"),
                ),
                const PopupMenuItem(
                  value: "Link Devices",
                  child: Text("Link Devices"),
                ),
                const PopupMenuItem(
                  value: "Settings",
                  child: Text("Settings"),
                ),
              ];
            },
          ),
        ],
        bottom: TabBar(
            controller: tabController,
            labelColor: Colors.white,
            indicatorColor: Colors.white,
            indicatorSize: TabBarIndicatorSize.tab,
            unselectedLabelColor: Colors.white70,
            physics: const NeverScrollableScrollPhysics(),
            
            tabs: const [              
              Tab(text: "CHATS"),
              Tab(text: "STATUS"),
              Tab(text: "CALLS"),
            ]),
      ),
      body: TabBarView(controller: tabController, children: [
        //camera

        //chats
        const ChatInboxScreen(),
        Container(
          color: Colors.lime,
        ),
        Container(
          color: Colors.redAccent,
        ),
      ]),
    );
  }
}
