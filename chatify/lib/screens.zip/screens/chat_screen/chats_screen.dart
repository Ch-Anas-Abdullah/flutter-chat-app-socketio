import 'dart:async';
import 'dart:developer';
import 'dart:math' as math;
import 'package:chatify/screens/auth_screen/login_screen.dart';
import 'package:chatify/screens/home_screen/chat_bubble.dart';
import 'package:flutter/foundation.dart' as foundation;
import 'package:chatify/widgets/media_query_size.dart';
import 'package:emoji_picker_flutter/emoji_picker_flutter.dart';
import 'package:flutter/material.dart';
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:socket_io_client/socket_io_client.dart' as io;

class ChatScreen extends StatefulWidget {
  final Contact contact;
  const ChatScreen({super.key, required this.contact});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  TextEditingController messageTextController = TextEditingController();
  bool showEmojiPicker = false;
  FocusNode focusNode = FocusNode();
  late io.Socket socket;
  late final ScrollController _controller;
  List<CustomChatBubble> messages = [];
  @override
  void initState() {
    _controller = ScrollController();
    focusNode.addListener(() {
      if (focusNode.hasFocus) {
        setState(() {
          showEmojiPicker = false;
        });
      }
    });
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _controller.jumpTo(_controller.position.maxScrollExtent);
    });
    connectSocket();
    super.initState();
  }

  connectSocket() {
    socket = io.io("http://192.168.1.42:5000", <String, dynamic>{
      "transports": ["websocket"],
      "autoConnect": false
    });

    socket.connect();
    socket.onConnect((data) {});
    log(socket.connected.toString());
    socket.on("message", (data) {
      log(data.toString());
      messages.add(CustomChatBubble(
          isMe: widget.contact.phones.first.number
              .replaceAll(RegExp(r'[+\-() ]+'), '')
              .contains(data["recieverId"]),
          message: data["message"]));
      setState(() {});
      _controller.jumpTo(_controller.position.maxScrollExtent + 60);
    });
  }

  @override
  void dispose() {
    socket.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        if (showEmojiPicker) {
          setState(() {
            showEmojiPicker = false;
          });
        } else {
          Navigator.pop(context);
        }
        return Future.value(false);
      },
      child: Scaffold(
        backgroundColor: Colors.blue.shade100,
        appBar: AppBar(
          leadingWidth: 80,
          leading: ElevatedButton(
            style: ElevatedButton.styleFrom(
                alignment: Alignment.center,
                padding: EdgeInsets.zero,
                backgroundColor: Colors.transparent,
                elevation: 0,
                shadowColor: Colors.transparent),
            onPressed: () {
              Navigator.pop(context);
            },
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(
                  Icons.arrow_back,
                  color: Colors.white,
                ),
                const SizedBox(width: 3),
                CircleAvatar(
                  radius: 20,
                  backgroundColor: Colors.grey.shade400,
                  child: const Icon(
                    Icons.person,
                    color: Colors.white,
                    size: 30,
                  ),
                ),
              ],
            ),
          ),
          titleSpacing: 0,
          title: ListTile(
            contentPadding: EdgeInsets.zero,
            textColor: Colors.white,
            title: Text(
              widget.contact.displayName,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            subtitle: const Text(
              "Online",
              style: TextStyle(color: Colors.grey),
            ),
          ),
          actions: [
            IconButton(onPressed: () {}, icon: const Icon(Icons.videocam)),
            IconButton(onPressed: () {}, icon: const Icon(Icons.call)),
            PopupMenuButton(
              position: PopupMenuPosition.under,
              itemBuilder: (context) {
                return [
                  const PopupMenuItem(
                    value: "New Group",
                    child: Text("New Group"),
                  ),
                  const PopupMenuItem(
                    value: "New Broadcast",
                    child: Text("New Broadcast"),
                  ),
                  const PopupMenuItem(
                    value: "Stared Messages",
                    child: Text("Stared Messages"),
                  ),
                  const PopupMenuItem(
                    value: "Link Devices",
                    child: Text("Link Devices"),
                  ),
                  const PopupMenuItem(
                    value: "Settings",
                    child: Text("Settings"),
                  ),
                ];
              },
            ),
          ],
        ),
        body: SizedBox(
          height: context.height,
          width: context.width,
          child: Column(
            children: [
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  child: ListView(
                      controller: _controller,
                      shrinkWrap: true,
                      padding: EdgeInsets.only(top: 15),
                      children: messages
                          .map((e) => Padding(
                                padding: const EdgeInsets.only(bottom: 15),
                                child: e,
                              ))
                          .toList()),
                ),
              ),
              Align(
                alignment: Alignment.bottomCenter,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      margin: const EdgeInsets.only(bottom: 10, left: 10),
                      padding: EdgeInsets.zero,
                      alignment: Alignment.center,
                      height: 50,
                      child: Row(
                        children: [
                          Flexible(
                              child: TextFormField(
                            focusNode: focusNode,
                            controller: messageTextController,
                            onChanged: (value) => setState(() {}),
                            textAlignVertical: TextAlignVertical.center,
                            keyboardType: TextInputType.multiline,
                            maxLines: 5,
                            minLines: 1,
                            decoration: InputDecoration(
                              isDense: true,
                              isCollapsed: true,
                              fillColor: Colors.white,
                              filled: true,
                              hintText: "Message",
                              hintStyle: const TextStyle(color: Colors.grey),
                              prefixIcon: IconButton(
                                  onPressed: () async {
                                    focusNode.unfocus();
                                    await Future.delayed(
                                        const Duration(milliseconds: 500));
                                    // focusNode.canRequestFocus = false;
                                    setState(() {
                                      showEmojiPicker = !showEmojiPicker;
                                    });
                                    if (!showEmojiPicker) {
                                      focusNode.requestFocus();
                                    }
                                  },
                                  icon: const Icon(
                                    Icons.emoji_emotions_outlined,
                                    size: 28,
                                    color: Colors.grey,
                                  )),
                              suffixIcon: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Align(
                                    child: IconButton(
                                        onPressed: () {
                                          showModalBottomSheet(
                                            context: context,
                                            backgroundColor: Colors.transparent,
                                            builder: (context) => Container(
                                              height: 278,
                                              decoration: BoxDecoration(
                                                  color: Colors.white,
                                                  borderRadius:
                                                      BorderRadius.circular(8)),
                                              margin: const EdgeInsets.all(10),
                                              child: const Column(
                                                mainAxisAlignment:
                                                    MainAxisAlignment
                                                        .spaceEvenly,
                                                children: [
                                                  Row(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .spaceAround,
                                                    children: [
                                                      MediaSelectorButton(
                                                        fgClr:
                                                            Colors.deepPurple,
                                                        icon: Icons.file_copy,
                                                        text: "Document",
                                                      ),
                                                      MediaSelectorButton(
                                                        fgClr: Colors.redAccent,
                                                        icon: Icons.camera_alt,
                                                        text: "Camera",
                                                      ),
                                                      MediaSelectorButton(
                                                        fgClr: Colors.purple,
                                                        icon: Icons.image,
                                                        text: "Gallery",
                                                      )
                                                    ],
                                                  ),
                                                  Row(
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .spaceAround,
                                                    children: [
                                                      MediaSelectorButton(
                                                        fgClr: Colors.orange,
                                                        icon: Icons.headphones,
                                                        text: "Audio",
                                                      ),
                                                      MediaSelectorButton(
                                                        fgClr: Colors.green,
                                                        icon: Icons.location_on,
                                                        text: "Location",
                                                      ),
                                                      MediaSelectorButton(
                                                        fgClr:
                                                            Colors.blueAccent,
                                                        icon: Icons.person,
                                                        text: "Contact",
                                                      )
                                                    ],
                                                  )
                                                ],
                                              ),
                                            ),
                                          );
                                        },
                                        icon: Transform.rotate(
                                          angle: math.pi / 0.8,
                                          child: const Icon(
                                            Icons.attach_file,
                                            size: 28,
                                            color: Colors.grey,
                                          ),
                                        )),
                                  ),
                                  if (messageTextController.text.isEmpty)
                                    IconButton(
                                        onPressed: () {},
                                        icon: const Icon(
                                          Icons.camera_alt,
                                          size: 28,
                                          color: Colors.grey,
                                        )),
                                ],
                              ),
                              border: OutlineInputBorder(
                                borderSide:
                                    BorderSide(color: Colors.grey.shade200),
                                borderRadius: BorderRadius.circular(30),
                              ),
                            ),
                          )),
                          ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                  alignment: Alignment.center,
                                  fixedSize: const Size(50, 50),
                                  padding: EdgeInsets.zero,
                                  shape: const CircleBorder(),
                                  backgroundColor: Colors.green.shade900,
                                  foregroundColor: Colors.white,
                                  elevation: 0,
                                  shadowColor: Colors.transparent),
                              onPressed: () {
                                if (messageTextController.text.isNotEmpty) {
                                  messages.add(CustomChatBubble(
                                      isMe: true,
                                      message: messageTextController.text));
                                  setState(() {});
                                  _controller.jumpTo(
                                      _controller.position.maxScrollExtent +
                                          60);
                                  socket.emit("message", {
                                    "message": messageTextController.text,
                                    "recieverId": widget
                                        .contact.phones.first.number
                                        .replaceAll(RegExp(r'[+\-() ]+'), ''),
                                    "senderId": loggedInUser.phones.first.number
                                        .replaceAll(RegExp(r'[+\-() ]+'), '')
                                  });
                                }
                              },
                              child: Icon(messageTextController.text.isEmpty
                                  ? Icons.mic
                                  : Icons.send))
                        ],
                      ),
                    ),
                    showEmojiPicker
                        ? SizedBox(height: 300, child: emojiPick())
                        : Container()
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget emojiPick() {
    return EmojiPicker(
      onEmojiSelected: (category, emoji) {
        setState(() {});
      },
      onBackspacePressed: () {
        setState(() {});
        // Do something when the user taps the backspace button (optional)
        // Set it to null to hide the Backspace-Button
      },
      textEditingController:
          messageTextController, // pass here the same [TextEditingController] that is connected to your input field, usually a [TextFormField]
      config: Config(
        columns: 7,
        emojiSizeMax: 32 *
            (foundation.defaultTargetPlatform == TargetPlatform.iOS
                ? 1.30
                : 1.0), // Issue: https://github.com/flutter/flutter/issues/28894
        verticalSpacing: 0,
        horizontalSpacing: 0,
        gridPadding: EdgeInsets.zero,
        initCategory: Category.RECENT,
        bgColor: const Color(0xFFF2F2F2),
        indicatorColor: Colors.blue,
        iconColor: Colors.grey,
        iconColorSelected: Colors.blue,
        backspaceColor: Colors.blue,
        skinToneDialogBgColor: Colors.white,
        skinToneIndicatorColor: Colors.grey,
        enableSkinTones: true,
        recentTabBehavior: RecentTabBehavior.RECENT,
        recentsLimit: 28,
        noRecents: const Text(
          'No Recents',
          style: TextStyle(fontSize: 20, color: Colors.black26),
          textAlign: TextAlign.center,
        ), // Needs to be const Widget
        loadingIndicator: const SizedBox.shrink(), // Needs to be const Widget
        tabIndicatorAnimDuration: kTabScrollDuration,
        categoryIcons: const CategoryIcons(),
        buttonMode: ButtonMode.MATERIAL,
      ),
    );
  }
}

class MediaSelectorButton extends StatelessWidget {
  final IconData icon;
  final Color fgClr;
  final String text;
  const MediaSelectorButton({
    super.key,
    required this.icon,
    required this.fgClr,
    required this.text,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      mainAxisSize: MainAxisSize.min,
      children: [
        ElevatedButton(
            style: ElevatedButton.styleFrom(
                alignment: Alignment.center,
                fixedSize: const Size(70, 70),
                padding: EdgeInsets.zero,
                shape: const CircleBorder(),
                backgroundColor: fgClr,
                foregroundColor: Colors.white,
                elevation: 0,
                shadowColor: Colors.transparent),
            onPressed: () {},
            child: Icon(
              icon,
              size: 33,
            )),
        const SizedBox(height: 10),
        Text(text)
      ],
    );
  }
}
