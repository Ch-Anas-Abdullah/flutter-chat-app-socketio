import 'dart:developer';

import 'package:chatify/screens/chat_screen/chats_screen.dart';
import 'package:chatify/screens/contact_screen/create_group_screen.dart';
import 'package:chatify/screens/home_screen/home_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:socket_io_client/socket_io_client.dart' as io;

late Contact loggedInUser;

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          centerTitle: false,
          titleSpacing: 0,
          title: ListTile(
            textColor: Colors.white,
            title: const Text("Login As"),
            subtitle: Text(
              "${contacts?.length ?? 0} contacts",
              style: const TextStyle(color: Colors.grey),
            ),
          ),
          actions: [
            IconButton(onPressed: () {}, icon: const Icon(Icons.search)),
            // IconButton(onPressed: () {}, icon: const Icon(Icons.call)),
            PopupMenuButton(
              padding: EdgeInsets.zero,
              itemBuilder: (context) {
                return [
                  const PopupMenuItem(
                    value: "Invite a friend",
                    child: Text("Invite a friend"),
                  ),
                  const PopupMenuItem(
                    value: "Contacts",
                    child: Text("Contacts"),
                  ),
                  const PopupMenuItem(
                    value: "Refresh",
                    child: Text("Refresh"),
                  ),
                  const PopupMenuItem(
                    value: "Help",
                    child: Text("Help"),
                  ),
                ];
              },
            ),
          ],
        ),
        body: _body());
  }

  Widget _body() {
    // if (_permissionDenied) {
    //   return const Center(child: Text('Permission denied.'));
    // }
    if (contacts == null) {
      return const Center(child: CircularProgressIndicator());
    }
    return ListView(
      children: [
        ListView.builder(
            itemCount: contacts!.length,
            physics: const NeverScrollableScrollPhysics(),
            cacheExtent: 100,
            shrinkWrap: true,
            itemBuilder: (context, i) => ListTile(
                  onTap: () {
                    late io.Socket socket;
                    socket =
                        io.io("http://192.168.1.42:5000", <String, dynamic>{
                      "transports": ["websocket"],
                      "autoConnect": false
                    });

                    socket.connect();
                    socket.onConnect((data) {
                      
                      var input = contacts![i].phones.first.number.toString();
                      input = input.replaceAll(RegExp(r'[+\-() ]+'), '');
                      loggedInUser = contacts![i];
                      
                      socket.emit("signin", input);
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const HomeScreen(),
                          ));
                    });
                  },
                  leading: CircleAvatar(
                    radius: 25,
                    backgroundColor: Colors.grey.shade400,
                    child: const Icon(
                      Icons.person,
                      color: Colors.white,
                      size: 35,
                    ),
                  ),
                  title: Text(
                    contacts![i].displayName,

                    style: const TextStyle(
                        fontWeight: FontWeight.w600, fontSize: 14),
                  ),
                  subtitle: Text(
                    contacts![i].phones.first.number,
                    style: const TextStyle(color: Colors.grey, fontSize: 12),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                )),
      ],
    );
  }
}
