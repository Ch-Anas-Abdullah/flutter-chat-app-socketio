import 'dart:convert';
import 'dart:math';

import 'package:camera/camera.dart';
import 'package:chatify/screens/auth_screen/login_screen.dart';
import 'package:chatify/screens/camera_screen/camera_screen.dart';
import 'package:chatify/screens/contact_screen/create_group_screen.dart';
import 'package:chatify/screens/home_screen/home_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';

late final SharedPreferences sharedPreferences;
late WidgetsBinding binding;
Future<void> main() async {
  binding = WidgetsFlutterBinding.ensureInitialized();
  Permission.camera.request();
  
  cameras = await availableCameras();
  sharedPreferences = await SharedPreferences.getInstance();
  var contact = sharedPreferences.getString("contacts");
  if (contact != null) {
    contacts = [];
    for (var element in jsonDecode(contact)) {
      contacts?.add(Contact.fromJson(element));
    }
  } else {
    _fetchContacts();
  }
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

Future _fetchContacts() async {
  await FlutterContacts.requestPermission();
  var per = await Permission.contacts.request();
  if (per.isDenied) {
    return;
  } else {
    final contactsList = await FlutterContacts.getContacts(
      withProperties: true,
    );
    List<Map<String,dynamic>> jsonList = [];
    for (var i = 0; i < contactsList.length; i++) {
      for (var element in contactsList[i].phones) {
        Map<String,dynamic> data = contactsList[i].toJson();
        data["phones"] = [element.toJson()];
        jsonList.add(data);
      }
    }

    sharedPreferences.setString("contacts", jsonEncode(jsonList));
    for (Map<String, dynamic> element in jsonList) {
      contacts?.add(Contact.fromJson(element));
    }
    contacts = contactsList;
    await binding.performReassemble();
  }
}

class _MyAppState extends State<MyApp> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      builder: (context, child) => MediaQuery(
          data: MediaQuery.of(context).copyWith(textScaleFactor: 1.0),
          child: child ?? Container()),
      theme: ThemeData(
          useMaterial3: true,
          floatingActionButtonTheme: const FloatingActionButtonThemeData(
              backgroundColor: Color.fromRGBO(27, 94, 32, 1),
              foregroundColor: Colors.white,
              shape: CircleBorder()),
          fontFamily: GoogleFonts.poppins().fontFamily,
          popupMenuTheme: const PopupMenuThemeData(color: Colors.white),
          appBarTheme: AppBarTheme(
              backgroundColor: Colors.green.shade900,
              foregroundColor: Colors.white,
              systemOverlayStyle: const SystemUiOverlayStyle(
                  statusBarColor: Colors.transparent,
                  statusBarIconBrightness: Brightness.light)),
          colorScheme: ColorScheme.fromSeed(
            seedColor: Colors.green.shade900,
          )),
      home: const LoginScreen(),
    );
  }
}
