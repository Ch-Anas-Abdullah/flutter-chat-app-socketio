import 'package:chatify/screens/chat_screen/chats_screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_contacts/flutter_contacts.dart';

class ChatCard extends StatelessWidget {
  final Contact contact;
  const ChatCard({super.key, required this.contact,});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      onTap: () {
        Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) =>  ChatScreen(contact: contact),
            ));
      },
      leading: CircleAvatar(
        radius: 25,
        backgroundColor: Colors.grey.shade400,
        child: const Icon(
          Icons.person,
          color: Colors.white,
          size: 35,
        ),
      ),
      title:  Text(contact.displayName),
      subtitle: const Row(
        children: [
          Icon(Icons.done_all, size: 20, color: Colors.grey),
          SizedBox(
            width: 5,
          ),
          Text(
            "Hey! How are you?",
            style: TextStyle(color: Colors.grey),
          )
        ],
      ),
      trailing: const Text("01:12"),
    );
  }
}
